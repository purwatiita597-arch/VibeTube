const tracks=[
 {title:"Rick Astley - Never Gonna Give You Up",artist:"Rick Astley",duration:"03:33",id:"dQw4w9WgXcQ"},
 {title:"Luis Fonsi - Despacito",artist:"Luis Fonsi",duration:"04:42",id:"kJQP7kiw5Fk"},
 {title:"Ed Sheeran - Perfect",artist:"Ed Sheeran",duration:"04:23",id:"2Vv-BfVoq4g"},
 {title:"Katy Perry - Roar",artist:"Katy Perry",duration:"03:43",id:"CevxZvSJLk8"}
];



/* ===== VibeTube Language System ===== */
const VIBE_LANG = {
 Indonesia: {},
 English: {
  "Dengarkan & Tonton":"Listen & Watch", "Tanpa Batas":"Without Limits",
  "Musik dan video favorit dalam satu pemutar.":"Your favorite music and videos in one player.",
  "Trending":"Trending", "Musik":"Music", "Video":"Video", "Playlist":"Playlist", "Favorit":"Favorites",
  "Rekomendasi":"Recommendations", "Lihat semua ›":"See all ›", "Belum ada lagu":"No song selected",
  "Beranda":"Home", "Eksplor":"Explore", "Subscription":"Subscription", "Koleksi":"Library", "Akun":"Account",
  "Cari YouTube":"Search YouTube", "Cari musik dan video favoritmu.":"Search for your favorite music and videos.",
  "Cari lagu atau video...":"Search songs or videos...", "Masukkan kata pencarian terlebih dahulu.":"Enter a search term first.",
  "API Key belum dimasukkan ke script.js":"YouTube API Key has not been added to script.js", "Mencari...":"Searching...",
  "Video tidak ditemukan.":"No videos found.", "Pencarian gagal":"Search failed", "Gagal memuat video":"Failed to load video",
  "Sekarang Diputar":"Now Playing", "Pilih video":"Select a video", "Audio":"Audio", "Video":"Video",
  "Berikutnya":"Up Next", "Auto play":"Auto play", "Pengaturan":"Settings", "Pengaturan Playback":"Playback Settings",
  "Kualitas Default":"Default Quality", "Mode Default":"Default Mode", "Ingat Posisi Terakhir":"Remember Last Position",
  "Pengaturan disimpan":"Settings saved", "Aktif":"On", "Nonaktif":"Off", "Reset Pengaturan":"Reset Settings",
  "Kembalikan pengaturan VibeTube ke default":"Restore VibeTube settings to default", "Reset":"Reset",
  "Atur pengalaman VibeTube sesuai kebutuhanmu.":"Customize your VibeTube experience.", "Playback":"Playback", "Tampilan":"Appearance", "Data":"Data",
  "Putar video berikutnya otomatis":"Automatically play the next video", "Mode default saat membuka player":"Default mode when opening the player",
  "Simpan posisi terakhir pemutaran":"Save the last playback position", "Tema":"Theme", "Tampilan VibeTube saat ini":"Current VibeTube appearance",
  "Hitam • Premium":"Black • Premium", "Bahasa":"Language", "Bahasa antarmuka":"Interface language",
  "Pilih bahasa aplikasi.":"Choose the app language.", "Indonesia":"Indonesian", "English":"English",
  "Vibe User":"Vibe User", "Belum login":"Not logged in", "Akun Google":"Google Account", "Langganan VIP":"VIP Subscription",
  "Download":"Downloads", "Profil dan status akun":"Profile and account status", "Nama":"Name", "Email":"Email",
  "Belum terhubung":"Not connected", "Status":"Status", "Masuk / Daftar":"Sign in / Register",
  "Google belum terhubung":"Google is not connected", "Hubungkan akun Google untuk sinkronisasi akun VibeTube.":"Connect your Google account to sync VibeTube.",
  "Hubungkan Google":"Connect Google",
  "Kelola daftar download VibeTube.":"Manage your VibeTube downloads.", "Tersedia":"Available", "Lokasi":"Location", "Perangkat":"Device", "Kualitas":"Quality", "Lihat Download":"View Downloads",
  "Belum ada file download":"No downloaded files", "Pilih paket VIP":"Choose a VIP plan", "Bisa diubah nanti":"Can be changed later",
  "Nikmati fitur premium tanpa batas.":"Enjoy unlimited premium features.", "Langganan Sekarang":"Subscribe Now",
  "Pembayaran VIP akan disambungkan nanti":"VIP payment will be connected later",
  "Pengaturan akan disambungkan nanti":"Settings will be connected later", "Trending":"Trending",
  "Shuffle aktif":"Shuffle on", "Shuffle mati":"Shuffle off", "Repeat mati":"Repeat off", "Repeat semua aktif":"Repeat all on", "Repeat satu aktif":"Repeat one on",
  "Antrean kosong":"Queue is empty", "Belum ada video":"No video selected", "Menyiapkan pemutar...":"Preparing player...",
  "Tekan Play YouTube untuk memulai":"Press YouTube Play to start", "Video YouTube tidak dapat diputar":"YouTube video could not be played",
  "Bahasa dipilih: ":"Language selected: ", "Auto play ON":"Auto play ON", "Auto play OFF":"Auto play OFF",
  "Visualizer mengikuti status pemutaran VibeTube. Audio YouTube tetap berjalan melalui player aslinya.":"The visualizer follows VibeTube playback status. YouTube audio continues through the original player.",
  "Visualizer":"Visualizer", "Equalizer":"Equalizer", "Night":"Night", "Flat":"Flat", "Bass Boost":"Bass Boost", "Vocal":"Vocal", "Treble":"Treble",
  "VIP Bulanan":"MONTHLY VIP", "VIP Tahunan":"YEARLY VIP", "Paling Populer":"MOST POPULAR", "Upgrade ke VibeTube VIP":"Upgrade to VibeTube VIP",
  "Pengalaman VibeTube yang lebih lengkap dengan tampilan premium hitam dan emas.":"A more complete VibeTube experience with a premium black and gold design.",
  "Bebas iklan":"Ad-free", "Putar di latar belakang*":"Background playback*", "Kualitas video tinggi":"High video quality", "Akses fitur premium":"Access premium features",
  "1 Bulan":"1 Month", "3 Bulan":"3 Months", "1 Tahun":"1 Year", "Audio YouTube tetap berjalan melalui player aslinya.":"YouTube audio continues through the original player."
 }
};
function getVibeLanguage(){
 const saved=localStorage.getItem("vibetubeLanguage");
 if(saved==="Japanese"||saved==="Korean"||saved==="ja"||saved==="ko"){
  localStorage.setItem("vibetubeLanguage","Indonesia");
  return "Indonesia";
 }
 return saved==="English"?"English":"Indonesia";
}
function tr(text){
 const lang=getVibeLanguage();
 if(lang!=="English") return text;
 return VIBE_LANG.English[text] || text;
}
function applyVibeLanguage(root=document.body){
 if(!root)return;
 const lang=getVibeLanguage();
 document.documentElement.lang=lang==="English"?"en":"id";
 document.title="VibeTube";
 if(lang!=="English")return;
 const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
 const nodes=[];
 while(walker.nextNode())nodes.push(walker.currentNode);
 nodes.forEach(n=>{
  const raw=n.nodeValue;
  const key=raw.trim();
  if(VIBE_LANG.English[key]) n.nodeValue=raw.replace(key,VIBE_LANG.English[key]);
 });
 root.querySelectorAll("input[placeholder]").forEach(el=>{if(VIBE_LANG.English[el.placeholder])el.placeholder=VIBE_LANG.English[el.placeholder]});
 root.querySelectorAll("[aria-label]").forEach(el=>{if(VIBE_LANG.English[el.getAttribute("aria-label")])el.setAttribute("aria-label",VIBE_LANG.English[el.getAttribute("aria-label")])});
}

let current=-1,player=null,mode="audio",ready=false,progressTimer=null;
let pendingVideoId=null;
let pendingPlay=false;
let playerInitStarted=false;
let currentVideoId=null;

let autoPlay=localStorage.getItem("vibetubeAutoPlay");
if(autoPlay===null) autoPlay=true; else autoPlay=autoPlay==="true";

function isVipUser(){
 return (typeof vipStatus!=="undefined" ? vipStatus : (localStorage.getItem("vibetubeVipStatus")||"free"))==="vip";
}
function showVipAutoPlayLock(){
 showToast("🔒 Auto Play adalah fitur VibeTube VIP");
 setTimeout(()=>{
   if(confirm("Auto Play adalah fitur VIP. Buka halaman Upgrade VIP sekarang?")){
     openPage("vip");
   }
 },120);
}
function updateAutoPlaySwitch(){
 const sw=document.getElementById("autoPlaySwitch");
 if(!sw)return;
 const vip=isVipUser();
 if(!vip) autoPlay=false;
 sw.classList.toggle("on",vip && autoPlay);
 sw.classList.toggle("locked",!vip);
 sw.setAttribute("aria-checked",(vip && autoPlay)?"true":"false");
 sw.setAttribute("aria-label",vip?"Toggle Auto Play":"Auto Play - VIP");
}
function toggleAutoPlay(){
 if(!isVipUser()){
   autoPlay=false;
   localStorage.setItem("vibetubeAutoPlay","false");
   updateAutoPlaySwitch();
   showVipAutoPlayLock();
   return;
 }
 autoPlay=!autoPlay;
 localStorage.setItem("vibetubeAutoPlay",String(autoPlay));
 updateAutoPlaySwitch();
 showToast(autoPlay?"Auto play ON":"Auto play OFF");
}

function getThumb(id){return id?`https://i.ytimg.com/vi/${encodeURIComponent(id)}/hqdefault.jpg`:""}

function renderTracks(){
 const list=document.getElementById("trackList");
 if(!list)return;
 list.innerHTML=tracks.map((t,i)=>`
 <article class="track" onclick="playTrack(${i})" style="cursor:pointer">
   <div class="thumb" style="background-image:url('${getThumb(t.id)}');background-size:cover;background-position:center"></div>
   <div class="track-info"><b>${escapeHtml(t.title)}</b><small>${escapeHtml(t.artist)} • ${t.duration}</small></div>
   <button class="play-small" onclick="event.stopPropagation();playTrack(${i})">▶</button>
 </article>`).join("");
}
renderTracks();
applyVibeLanguage(document.body);

function showPlayerPoster(videoId){
 const poster=document.getElementById("playerPoster");
 if(!poster)return;
 if(videoId && mode==="video"){
   poster.style.backgroundImage=`url('${getThumb(videoId)}')`;
   poster.classList.remove("hidden");
 }else{
   poster.style.backgroundImage="";
   poster.classList.add("hidden");
 }
}

function hidePlayerPoster(){
 document.getElementById("playerPoster")?.classList.add("hidden");
}

let youtubeApiLoading=false;
let youtubeApiFailed=false;
let youtubeApiTimeout=null;
let youtubePlayerReadyPromise=null;
let youtubePlayerRetryCount=0;
let youtubeApiLoadCount=0;

function loadYouTubeIframeAPI(){
  if(window.YT && window.YT.Player) return Promise.resolve(true);
  if(youtubePlayerReadyPromise) return youtubePlayerReadyPromise;

  youtubeApiLoading=true;
  youtubeApiFailed=false;
  youtubePlayerReadyPromise=new Promise((resolve,reject)=>{
    const finish=(ok)=>{
      clearTimeout(youtubeApiTimeout);
      youtubeApiLoading=false;
      if(ok){
        youtubeApiFailed=false;
        resolve(true);
      }else{
        youtubeApiFailed=true;
        youtubePlayerReadyPromise=null;
        reject(new Error("YouTube IFrame API tidak tersedia"));
      }
    };

    const existing=document.querySelector('script[data-vibetube-youtube-api="1"]');
    if(!existing){
      const s=document.createElement('script');
      s.src='https://www.youtube.com/iframe_api';
      s.async=true;
      s.dataset.vibetubeYoutubeApi='1';
      s.onerror=()=>finish(false);
      document.head.appendChild(s);
    }

    youtubeApiTimeout=setTimeout(()=>{
      if(!(window.YT && window.YT.Player)) finish(false);
    },15000);
  });
  return youtubePlayerReadyPromise;
}

function resetYouTubePlayer(){
  clearInterval(progressTimer);
  try{ if(player && typeof player.destroy==="function") player.destroy(); }catch(e){}
  player=null;
  ready=false;
  playerInitStarted=false;
}

function createYouTubePlayer(){
  if(ready && player) return Promise.resolve(true);

  return loadYouTubeIframeAPI().then(()=>{
    if(ready && player) return true;
    const target=document.getElementById('youtubePlayer');
    if(!target) throw new Error("Elemen YouTube player tidak ditemukan");

    // Android/WebView lebih stabil jika player dibuat setelah area player tersedia.
    if(playerInitStarted && player) return true;
    playerInitStarted=true;

    return new Promise((resolve,reject)=>{
      let settled=false;
      const settle=(ok,err)=>{
        if(settled) return;
        settled=true;
        if(ok) resolve(true);
        else reject(err||new Error("Gagal membuat pemutar YouTube"));
      };

      try{
        player=new YT.Player('youtubePlayer',{
          height:'100%',
          width:'100%',
          videoId:'',
          playerVars:{
            autoplay:0,
            playsinline:1,
            rel:0,
            modestbranding:1,
            enablejsapi:1
          },
          events:{
            onReady:()=>{
              ready=true;
              youtubePlayerRetryCount=0;
              updateProgress();
              updateAutoPlaySwitch();

              const id=pendingVideoId || currentVideoId;
              const shouldPlay=pendingPlay;
              pendingVideoId=null;
              pendingPlay=false;

              if(id){
                try{
                  if(shouldPlay) player.loadVideoById({videoId:id});
                  else player.cueVideoById({videoId:id});
                }catch(e){ console.error('YouTube initial load:',e); }
              }
              settle(true);
            },
            onStateChange:onPlayerStateChange,
            onError:(e)=>{
              const code=e&&e.data;
              console.warn('YouTube player error:',code);
              showPlayerPoster(currentVideoId);
              const msg={
                2:'ID video YouTube tidak valid',
                5:'Pemutar YouTube gagal',
                100:'Video YouTube tidak ditemukan',
                101:'Video tidak mengizinkan pemutaran di aplikasi',
                150:'Video tidak mengizinkan pemutaran di aplikasi'
              }[code]||'Video YouTube tidak dapat diputar';
              showToast(msg);
            }
          }
        });
      }catch(err){
        player=null;
        ready=false;
        playerInitStarted=false;
        settle(false,err);
      }

      setTimeout(()=>{
        if(!ready) settle(false,new Error("Pemutar YouTube terlalu lama merespons"));
      },16000);
    });
  }).catch(err=>{
    console.error('Create YouTube player failed:',err);
    player=null;
    ready=false;
    playerInitStarted=false;
    if(youtubePlayerRetryCount<1 && currentVideoId){
      youtubePlayerRetryCount++;
      setTimeout(()=>ensurePlayer(currentVideoId,pendingPlay),800);
    }
    return false;
  });
}

function onYouTubeIframeAPIReady(){
  youtubeApiLoading=false;
  clearTimeout(youtubeApiTimeout);
  // Jangan paksa membuat iframe saat modal masih hidden.
  // Player dibuat saat pengguna memilih/open player.
}

setTimeout(()=>{ loadYouTubeIframeAPI().catch(()=>{}); },0);

function ensurePlayer(videoId=null,shouldPlay=false){
  if(videoId){
    currentVideoId=videoId;
    pendingVideoId=videoId;
    pendingPlay=shouldPlay;
    if(mode==="video") showPlayerPoster(videoId);
  }
  if(ready && player) return Promise.resolve(true);
  return createYouTubePlayer();
}

function loadYouTubeVideo(videoId,shouldPlay=true){
 if(!videoId)return;
 currentVideoId=videoId;
 showPlayerPoster(videoId);
 if(!ready||!player){
   pendingVideoId=videoId;
   pendingPlay=shouldPlay;
   createYouTubePlayer();
   return;
 }
 try{
   if(shouldPlay)player.loadVideoById(videoId);
   else player.cueVideoById(videoId);
 }catch(err){
   console.error(err);
   showToast("Gagal memuat video");
 }
}

function activateVideoFromGesture(){
 if(!currentVideoId){showToast("Belum ada video");return}
 if(!ready||!player){
   pendingVideoId=currentVideoId;
   pendingPlay=true;
   createYouTubePlayer();
   showToast("Pemutar sedang disiapkan...");
   return;
 }
 try{
   hidePlayerPoster();
   player.playVideo();
 }catch(e){
   console.error(e);
   showToast("Tekan Play YouTube untuk memulai");
 }
}

function resumeCurrentVideo(){
 if(!currentVideoId){showToast("Belum ada video");return}
 if(!ready||!player){
   pendingVideoId=currentVideoId;
   pendingPlay=true;
   createYouTubePlayer();
   showToast("Pemutar sedang disiapkan...");
   return;
 }
 try{player.playVideo()}catch(e){console.error(e);showToast("Pemutar belum siap")}
}
function preparePlayerArea(){
 const modal=document.getElementById("playerModal");
 const wrap=document.getElementById("videoWrap");
 if(modal)modal.classList.remove("hidden");
 if(!wrap)return;
 if(mode==="audio"){
   wrap.style.display="block";
   wrap.style.visibility="visible";
   wrap.style.height="1px";
   wrap.style.minHeight="1px";
   wrap.style.opacity="0.01";
   wrap.style.position="absolute";
   wrap.style.left="0";
   wrap.style.top="0";
   wrap.style.pointerEvents="none";
 }else{
   wrap.style.display="block";
   wrap.style.visibility="visible";
   wrap.style.height="";
   wrap.style.minHeight="";
   wrap.style.opacity="1";
   wrap.style.position="relative";
   wrap.style.left="";
   wrap.style.top="";
   wrap.style.pointerEvents="auto";
 }
}

function updateProgress(){
 clearInterval(progressTimer);
 progressTimer=setInterval(()=>{
   if(!player||!ready)return;
   try{
     const d=player.getDuration()||0,t=player.getCurrentTime()||0;
     if(d>0){
       const p=document.getElementById("progress"),ct=document.getElementById("currentTime"),du=document.getElementById("duration");
       if(p)p.value=t/d*100;
       if(ct)ct.textContent=formatTime(t);
       if(du)du.textContent=formatTime(d);
     }
   }catch(e){}
 },500);
}
function formatTime(sec){sec=Math.max(0,Math.floor(sec));return String(Math.floor(sec/60)).padStart(2,"0")+":"+String(sec%60).padStart(2,"0")}
function seekVideo(v){
 if(player&&ready){try{const d=player.getDuration()||0;if(d>0)player.seekTo(Number(v)/100*d,true)}catch(e){}}
}

function onPlayerStateChange(e){
 const playing=e.data===YT.PlayerState.PLAYING;
 const a=document.getElementById("mainPlay"),b=document.getElementById("barPlay");

 if(playing){
   hidePlayerPoster();
   if(a)a.textContent="Ⅱ";
   if(b)b.textContent="Ⅱ";
 }else{
   if(a)a.textContent="▶";
   if(b)b.textContent="▶";
 }

 if(e.data===YT.PlayerState.ENDED){
   if(repeatMode==="one" && currentVideoId){
     loadYouTubeVideo(currentVideoId,true);
   }else if(autoPlay && tracks.length){
     nextTrack();
   }
 }
}

function setNowPlaying(title,artist,duration,thumbId){
 const vals={currentTime:"00:00",duration:duration||"YouTube",nowTitle:title,nowArtist:artist,barTitle:title,barArtist:artist};
 Object.keys(vals).forEach(id=>{const x=document.getElementById(id);if(x)x.textContent=vals[id]});

 const thumb=document.getElementById("barThumb");
 if(thumb&&thumbId)thumb.style.backgroundImage=`url('${getThumb(thumbId)}')`;
 if(thumb){
   thumb.style.backgroundSize="cover";
   thumb.style.backgroundPosition="center";
 }
 showPlayerPoster(thumbId);

 const p=document.getElementById("progress");
 if(p)p.value=0;
}

function playTrack(i){
 if(!tracks[i])return;
 const selectedQueueItem=queueFromTrack(tracks[i]);
 if(!queueItems.some(x=>queueKey(x)===queueKey(selectedQueueItem)))queueItems.push(selectedQueueItem);
 renderQueue();
 current=i;
 const t=tracks[i];

 setNowPlaying(t.title,t.artist,t.duration,t.id);
 document.getElementById("playerBar")?.classList.remove("hidden");
 preparePlayerArea();

 // Preload/cue the selected video. The later VibeTube ▶ button then calls
 // playVideo() directly without changing Audio -> Video.
 currentVideoId=t.id;
 pendingVideoId=t.id;
 pendingPlay=false;

 if(ready&&player){
   try{
     player.cueVideoById(t.id);
     hidePlayerPoster();
   }catch(e){
     console.error(e);
     showToast("Gagal menyiapkan video");
   }
 }else{
   createYouTubePlayer();
   showToast("Menyiapkan pemutar...");
 }
}

function openPlayer(){
 preparePlayerArea();
 ensurePlayer();
}

function closePlayer(){document.getElementById("playerModal")?.classList.add("hidden")}

function togglePlay(){
 if(!currentVideoId){
   showToast("Pilih lagu atau video terlebih dahulu");
   return;
 }

 // IMPORTANT: this button must never call activateVideoFromGesture(),
 // because that function intentionally switches to Video mode.
 // Audio mode stays Audio when this button is pressed.
 if(!player||!ready){
   showToast("Pemutar sedang disiapkan...");
   ensurePlayer(currentVideoId,false);
   return;
 }

 try{
   const s=player.getPlayerState();
   if(s===YT.PlayerState.PLAYING){
     player.pauseVideo();
   }else{
     player.playVideo();
   }
 }catch(e){
   console.error(e);
   showToast("Pemutar belum siap");
 }
}

function setMode(m){
 mode=m;
 document.getElementById("audioMode")?.classList.toggle("selected",m==="audio");
 document.getElementById("videoMode")?.classList.toggle("selected",m==="video");
 const w=document.getElementById("videoWrap");
 if(!w)return;
 if(m==="audio"){
   // Keep YouTube iframe alive. Do not use display:none or visibility:hidden,
   // because those can interrupt playback in mobile WebView.
   w.style.display="block";
   w.style.visibility="visible";
   w.style.height="1px";
   w.style.minHeight="1px";
   w.style.opacity="0.01";
   w.style.position="absolute";
   w.style.left="0";
   w.style.pointerEvents="none";
 }else{
   w.style.display="block";
   w.style.visibility="visible";
   w.style.height="";
   w.style.minHeight="";
   w.style.opacity="1";
   w.style.position="";
   w.style.left="";
   w.style.pointerEvents="auto";
 }
}

let queueItems=[];

function queueKey(item){
 return String(item?.id||"")+"|"+String(item?.title||"");
}
function queueFromTrack(t){
 return {id:t.id,title:t.title,artist:t.artist,duration:t.duration||"YouTube"};
}
function addToQueue(item,notify=true){
 if(!item?.id)return;
 if(queueItems.some(x=>queueKey(x)===queueKey(item))){
   if(notify)showToast("Sudah ada di antrean");
   return;
 }
 queueItems.push({...item});
 renderQueue();
 if(notify)showToast("Ditambahkan ke antrean");
}
function addTrackToQueue(i){
 if(tracks[i])addToQueue(queueFromTrack(tracks[i]));
}
function addSearchToQueue(i){
 const v=window.youtubeSearchItems?.[i];
 if(!v)return;
 const sn=v.snippet||{};
 addToQueue({id:v.id.videoId,title:sn.title||"YouTube",artist:sn.channelTitle||"YouTube",duration:"YouTube"});
}
function removeFromQueue(i){
 if(i<0||i>=queueItems.length)return;
 queueItems.splice(i,1);
 renderQueue();
 showToast("Dihapus dari antrean");
}
function clearQueue(){
 queueItems=[];
 renderQueue();
 showToast("Antrean dibersihkan");
}
function renderQueue(){
 const list=document.getElementById("queueList");
 const count=document.getElementById("queueCount");
 if(!list)return;
 if(count)count.textContent=`${queueItems.length} item`;
 if(!queueItems.length){
   list.innerHTML='<div class="queue-empty">Antrean masih kosong. Tambahkan lagu dengan tombol ＋.</div>';
   return;
 }
 list.innerHTML=queueItems.map((q,i)=>`
   <div class="queue-item">
    <div class="queue-thumb" style="background-image:url('${getThumb(q.id)}')"></div>
    <div class="queue-meta"><b>${escapeHtml(q.title)}</b><small>${escapeHtml(q.artist)}</small></div>
    <button class="queue-play" type="button" onclick="playQueueItem(${i})">▶</button>
    <button class="queue-remove" type="button" onclick="removeFromQueue(${i})">✕</button>
   </div>`).join("");
}
function playQueueItem(i){
 const q=queueItems[i];
 if(!q)return;
 const ti=tracks.findIndex(t=>t.id===q.id);
 if(ti>=0){playTrack(ti);return;}
 current=-1;
 currentVideoId=q.id;
 setNowPlaying(q.title,q.artist,q.duration,q.id);
 document.getElementById("playerBar")?.classList.remove("hidden");
 preparePlayerArea();
 if(ready&&player){
   try{player.cueVideoById(q.id);hidePlayerPoster()}catch(e){console.error(e)}
 }else{
   pendingVideoId=q.id;
   createYouTubePlayer();
 }
}
function getPlaybackList(){
 return queueItems.length?queueItems:tracks.map(queueFromTrack);
}
function playQueueOrTrack(item){
 const ti=tracks.findIndex(t=>t.id===item.id);
 if(ti>=0){playTrack(ti);return;}
 current=-1;
 currentVideoId=item.id;
 setNowPlaying(item.title,item.artist,item.duration,item.id);
 document.getElementById("playerBar")?.classList.remove("hidden");
 preparePlayerArea();
 loadYouTubeVideo(item.id,true);
}
function getNextQueueIndex(){
 const list=getPlaybackList();
 if(!list.length)return -1;
 const currentIndex=list.findIndex(x=>x.id===currentVideoId);
 if(repeatMode==="one")return currentIndex>=0?currentIndex:0;
 if(shuffleEnabled&&list.length>1){
   let n=currentIndex;
   for(let guard=0;guard<12&&n===currentIndex;guard++)n=Math.floor(Math.random()*list.length);
   return n;
 }
 if(currentIndex>=0){
   if(currentIndex+1<list.length)return currentIndex+1;
   if(repeatMode==="all")return 0;
   return -1;
 }
 return 0;
}
renderQueue();

function nextTrack(){
 const list=getPlaybackList();
 if(!list.length){showToast("Antrean kosong");return}
 const n=getNextQueueIndex();
 if(n<0){showToast("Antrean selesai");return}
 playQueueOrTrack(list[n]);
}



let eqBands=[0,0,0,0,0];
const eqPresets={
 flat:[0,0,0,0,0],
 bass:[8,5,1,-1,-2],
 vocal:[-2,2,5,4,2],
 treble:[-2,-1,1,5,8],
 night:[3,2,-1,-3,-5]
};

function openEqualizer(){
 document.getElementById("equalizerPanel")?.classList.add("show");
 updateEqUI();
}
function closeEqualizer(){
 document.getElementById("equalizerPanel")?.classList.remove("show");
}
function setEqBand(i,value){
 eqBands[i]=Number(value);
 const out=document.getElementById("eqOut"+i);
 if(out)out.textContent=(eqBands[i]>0?"+":"")+eqBands[i]+" dB";
 document.querySelectorAll(".eq-presets button").forEach(b=>b.classList.remove("active"));
 localStorage.setItem("vibetubeEq",JSON.stringify(eqBands));
}
function applyEqPreset(name,button){
 eqBands=[...(eqPresets[name]||eqPresets.flat)];
 updateEqUI();
 document.querySelectorAll(".eq-presets button").forEach(b=>b.classList.remove("active"));
 button?.classList.add("active");
 localStorage.setItem("vibetubeEq",JSON.stringify(eqBands));
 showToast("Equalizer: "+(name==="flat"?"Flat":name.replace("-"," ")));
}
function updateEqUI(){
 eqBands.forEach((v,i)=>{
   const input=document.getElementById("eq"+i);
   const out=document.getElementById("eqOut"+i);
   if(input)input.value=v;
   if(out)out.textContent=(v>0?"+":"")+v+" dB";
 });
}
function resetEqualizer(){
 applyEqPreset("flat",document.querySelector('.eq-presets button[data-preset="flat"]'));
 showToast("Equalizer di-reset");
}
try{
 const saved=JSON.parse(localStorage.getItem("vibetubeEq")||"null");
 if(Array.isArray(saved)&&saved.length===5)eqBands=saved.map(Number);
}catch(e){}


let vizMode="bars";
let vizRAF=0;
let vizRunning=false;

function openVisualizer(){
 const p=document.getElementById("visualizerPanel");
 if(!p)return;
 p.classList.add("show");
 const active=document.querySelector('.viz-presets button[data-viz="'+vizMode+'"]');
 setVisualizer(vizMode,active,true);
}
function closeVisualizer(){
 const p=document.getElementById("visualizerPanel");
 if(p)p.classList.remove("show");
}
function setVisualizer(mode,button,silent=false){
 vizMode=mode||"bars";
 document.querySelectorAll(".viz-presets button").forEach(b=>b.classList.remove("active"));
 if(button)button.classList.add("active");
 localStorage.setItem("vibetubeViz",vizMode);
 startVisualizer();
 if(!silent)showToast("Visualizer: "+vizMode);
}
function vizPlaying(){
 return (typeof isPlaying!=="undefined" && isPlaying) ||
        (typeof player!=="undefined" && player && typeof player.getPlayerState==="function" && player.getPlayerState()===1);
}
function startVisualizer(){
 if(vizRunning)return;
 const canvas=document.getElementById("visualizerCanvas");
 if(!canvas)return;
 const ctx=canvas.getContext("2d");
 vizRunning=true;
 function frame(t){
   const panel=document.getElementById("visualizerPanel");
   if(!panel || !panel.classList.contains("show")){
     vizRunning=false;vizRAF=0;return;
   }
   const dpr=window.devicePixelRatio||1;
   const w=canvas.clientWidth||320,h=canvas.clientHeight||190;
   if(canvas.width!==Math.floor(w*dpr)||canvas.height!==Math.floor(h*dpr)){
     canvas.width=Math.floor(w*dpr);canvas.height=Math.floor(h*dpr);
     ctx.setTransform(dpr,0,0,dpr,0,0);
   }
   ctx.clearRect(0,0,w,h);
   const playing=vizPlaying();
   const speed=playing?1:0.22;
   const pulse=playing?(Math.sin(t*.006)+1)/2:.12;

   // premium background grid
   const grad=ctx.createRadialGradient(w/2,h/2,8,w/2,h/2,Math.max(w,h)*.72);
   grad.addColorStop(0,"rgba(218,185,76,.10)");
   grad.addColorStop(1,"rgba(0,0,0,0)");
   ctx.fillStyle=grad;ctx.fillRect(0,0,w,h);

   ctx.strokeStyle="rgba(218,185,76,.055)";
   ctx.lineWidth=1;
   for(let y=20;y<h;y+=28){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}

   if(vizMode==="bars"){
     const count=32, gap=3, bw=Math.max(2,(w-gap*(count-1))/count);
     for(let i=0;i<count;i++){
       const wave=Math.sin(t*.004*speed+i*.48);
       const wave2=Math.sin(t*.0018*speed+i*.16);
       const level=playing?(Math.abs(wave)*.52+Math.abs(wave2)*.30+.14):(.06+Math.abs(wave)*.025);
       const bh=Math.max(5,level*h*.62);
       const x=i*(bw+gap), y=h*.82-bh;
       const g=ctx.createLinearGradient(0,y,0,h*.82);
       g.addColorStop(0,"#f0d56b");g.addColorStop(.55,"#d9b84c");g.addColorStop(1,"rgba(217,184,76,.12)");
       ctx.fillStyle=g;
       ctx.shadowBlur=playing?8:0;ctx.shadowColor="rgba(217,184,76,.45)";
       ctx.fillRect(x,y,bw,bh);ctx.shadowBlur=0;
     }
   }else if(vizMode==="wave"){
     for(let line=0;line<3;line++){
       ctx.beginPath();
       ctx.lineWidth=line===1?2:1;
       ctx.strokeStyle=line===1?"#e4c65f":"rgba(218,185,76,.28)";
       for(let x=0;x<=w;x+=4){
         const n=x/w*9;
         const y=h/2+Math.sin(n+t*.004*speed+line*.9)*h*(.10+line*.035)*(playing?1:.25)
                   +Math.sin(n*2.1-t*.002*speed)*h*.035;
         if(x===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);
       }
       ctx.shadowBlur=line===1?12:0;ctx.shadowColor="rgba(226,198,95,.5)";ctx.stroke();ctx.shadowBlur=0;
     }
   }else{
     const cx=w/2,cy=h/2;
     for(let ring=0;ring<4;ring++){
       const r=22+ring*21+pulse*(playing?14:3);
       ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);
       ctx.lineWidth=ring===0?2:1;
       ctx.strokeStyle=ring===0?"#e4c65f":`rgba(218,185,76,${.22-ring*.035})`;
       ctx.shadowBlur=ring===0?14:0;ctx.shadowColor="rgba(218,185,76,.55)";
       ctx.stroke();ctx.shadowBlur=0;
     }
     for(let i=0;i<18;i++){
       const ang=i/18*Math.PI*2+t*.00025*speed;
       const r=48+pulse*18;
       const x=cx+Math.cos(ang)*r,y=cy+Math.sin(ang)*r;
       ctx.beginPath();ctx.arc(x,y,1.5+2*pulse,0,Math.PI*2);
       ctx.fillStyle="#d9b84c";ctx.fill();
     }
   }

   const status=document.getElementById("vizStatus");
   if(status)status.textContent=playing?"● PLAYING":"● READY";
   vizRAF=requestAnimationFrame(frame);
 }
 vizRAF=requestAnimationFrame(frame);
}
try{
 const saved=localStorage.getItem("vibetubeViz");
 if(saved)vizMode=saved;
}catch(e){}

function vipFeatureAction(feature){
 if(feature==="audio"){
   if(typeof openPlayer==="function")openPlayer();
   setTimeout(()=>{if(typeof setMode==="function")setMode("audio")},80);
   showToast("Audio Mode dibuka");
   return;
 }
 if(feature==="queue"){
   if(typeof openPlayer==="function")openPlayer();
   setTimeout(()=>{
     const q=document.getElementById("queuePanel");
     if(q)q.scrollIntoView({behavior:"smooth",block:"center"});
   },120);
   showToast("Antrean dibuka");
   return;
 }
 if(feature==="autoplay"){
   if(typeof openPlayer==="function")openPlayer();
   showToast("Kontrol Auto Play dibuka");
   return;
 }
 if(feature==="sleep"){
   if(typeof openPlayer==="function")openPlayer();
   setTimeout(()=>{if(typeof openSleepTimer==="function")openSleepTimer()},120);
   showToast("Sleep Timer dibuka");
   return;
 }
 if(feature==="playlist"){
   if(typeof openPage==="function")openPage("collection");
   return;
 }
 if(feature==="badge"){
   if(typeof vipStatus!=="undefined" && vipStatus==="vip")showToast("👑 Status akun: VIP Premium");
   else showToast("Status saat ini: FREE — Upgrade untuk VIP");
   return;
 }
 if(feature==="equalizer"){
   openEqualizer();
   return;
 }
 if(feature==="visualizer"){
   openVisualizer();
   return;
 }
}


let vipStatus=localStorage.getItem("vibetubeVipStatus")||"free";
const vipVerified=localStorage.getItem("vibetubeVipVerified")==="true";
if(vipStatus==="vip" && !vipVerified){
 vipStatus="free";
 localStorage.setItem("vibetubeVipStatus","free");
}
if(vipStatus!=="vip"){ autoPlay=false; localStorage.setItem("vibetubeAutoPlay","false"); }
function activateVipDemo(plan){
 // Legacy compatibility: old VIP buttons must never activate VIP automatically.
 localStorage.setItem("vibetubePendingVipPlan", plan==="yearly" ? "yearly" : "monthly");
 if(typeof openVipPayment==="function") openVipPayment();
 else showToast("Membuka pembayaran VIP...");
}
function renderVipPage(){
 const page=document.getElementById("page");
 if(!page)return;
 page.innerHTML=`<div class="vip-page">
  <section class="vip-hero">
    <div class="vip-shine"></div>
    <div class="vip-crown">♛</div>
    <p class="vip-kicker">VibeTube Premium</p>
    <h1>Upgrade ke<br>VibeTube VIP</h1>
    <p>Pengalaman VibeTube yang lebih lengkap dengan tampilan premium hitam dan emas.</p>
  </section>

  <div class="vip-section-title"><h2>Pilih paket VIP</h2><span>Bisa diubah nanti</span></div>
  <section class="vip-plans">
    <article class="vip-plan">
      <div class="vip-plan-name">VIP BULANAN</div>
      <div class="vip-price">Rp19.000 <small>/ bulan</small></div>
      <span class="vip-save">Fleksibel, bayar bulanan</span>
      <button class="vip-buy" onclick="selectVipPayment('monthly')">👑 UPGRADE VIP</button>
    </article>
    <article class="vip-plan popular">
      <span class="vip-badge">PALING POPULER</span>
      <div class="vip-plan-name">VIP TAHUNAN</div>
      <div class="vip-price">Rp149.900 <small>/ tahun</small></div>
      <span class="vip-save">Hemat dibanding bulanan</span>
      <button class="vip-buy" onclick="selectVipPayment('yearly')">👑 UPGRADE VIP</button>
    </article>
  </section>
  <div id="vipPaymentDetail"></div>

  <div class="vip-section-title"><h2>Fitur Premium</h2><span>VibeTube</span></div>
  <section class="vip-features">
    <button type="button" class="vip-feature vip-feature-btn" onclick="vipFeatureAction('audio')"><i>♫</i><div class="vip-feature-text"><b>Audio Mode</b><small>Buka player Audio</small></div><span class="vip-feature-arrow">›</span></button>
    <button type="button" class="vip-feature vip-feature-btn" onclick="vipFeatureAction('queue')"><i>∞</i><div class="vip-feature-text"><b>Queue</b><small>Buka antrean pemutaran</small></div><span class="vip-feature-arrow">›</span></button>
    <button type="button" class="vip-feature vip-feature-btn" onclick="vipFeatureAction('autoplay')"><i>↻</i><div class="vip-feature-text"><b>Auto Play</b><small>Buka kontrol Auto Play</small></div><span class="vip-feature-arrow">›</span></button>
    <button type="button" class="vip-feature vip-feature-btn" onclick="vipFeatureAction('sleep')"><i>◷</i><div class="vip-feature-text"><b>Sleep Timer</b><small>Buka Sleep Timer</small></div><span class="vip-feature-arrow">›</span></button>
    <button type="button" class="vip-feature vip-feature-btn" onclick="vipFeatureAction('equalizer')"><i>≋</i><div class="vip-feature-text"><b>Equalizer</b><small>Menu Equalizer</small></div><span class="vip-feature-arrow">›</span></button>
    <button type="button" class="vip-feature vip-feature-btn" onclick="vipFeatureAction('visualizer')"><i>✦</i><div class="vip-feature-text"><b>Visualizer</b><small>Menu Visualizer</small></div><span class="vip-feature-arrow">›</span></button>
    <button type="button" class="vip-feature vip-feature-btn" onclick="vipFeatureAction('playlist')"><i>♡</i><div class="vip-feature-text"><b>Playlist</b><small>Buka Koleksi playlist</small></div><span class="vip-feature-arrow">›</span></button>
    <button type="button" class="vip-feature vip-feature-btn" onclick="vipFeatureAction('badge')"><i>👑</i><div class="vip-feature-text"><b>VIP Badge</b><small>Lihat status VIP</small></div><span class="vip-feature-arrow">›</span></button>
  </section>

  <div class="vip-note">Harga di atas adalah rancangan UI dan belum terhubung ke pembayaran. Saat VibeTube menjadi APK, tombol upgrade dapat dihubungkan ke sistem pembayaran resmi.</div>
</div>`;
 page.classList.remove("hidden");
 document.getElementById("main")?.classList.add("hidden");
}


let sleepTimerMinutes=0;
let sleepTimerHandle=null;
let sleepTimerEnd=0;

function openSleepTimer(){
 const card=document.getElementById("sleepTimerCard");
 if(card)card.classList.add("show");
 updateSleepTimerText();
}

function hideSleepTimer(){
 document.getElementById("sleepTimerCard")?.classList.remove("show");
}

function updateSleepTimerText(){
 const el=document.getElementById("sleepTimerStatus");
 if(!el)return;
 if(!sleepTimerEnd){el.textContent="Pilih kapan pemutaran dihentikan.";return}
 const left=Math.max(0,Math.ceil((sleepTimerEnd-Date.now())/60000));
 el.textContent=`Pemutaran akan berhenti dalam ${left} menit.`;
}

function setSleepTimer(minutes,button){
 if(sleepTimerHandle){clearTimeout(sleepTimerHandle);sleepTimerHandle=null}
 document.querySelectorAll(".sleep-timer-options button").forEach(b=>b.classList.remove("active"));
 button?.classList.add("active");

 if(minutes===0){
   sleepTimerMinutes=0;
   sleepTimerEnd=0;
   const el=document.getElementById("sleepTimerStatus");
   if(el)el.textContent="Sleep Timer dimatikan.";
   showToast("Sleep Timer dimatikan");
   return;
 }

 sleepTimerMinutes=minutes;
 sleepTimerEnd=Date.now()+minutes*60*1000;
 updateSleepTimerText();

 sleepTimerHandle=setTimeout(()=>{
   try{
     if(player && ready) player.pauseVideo();
   }catch(e){console.error(e)}
   sleepTimerHandle=null;
   sleepTimerEnd=0;
   sleepTimerMinutes=0;
   showToast("Sleep Timer selesai — pemutaran dihentikan");
   updateSleepTimerText();
 },minutes*60*1000);

 showToast(`Sleep Timer ${minutes} menit`);
}


let shuffleEnabled=false;
let repeatMode="off"; // off | all | one

function updateShuffleRepeatUI(){
 const s=document.getElementById("shuffleBtn");
 const r=document.getElementById("repeatBtn");
 if(s)s.classList.toggle("active",shuffleEnabled);
 if(r){
   r.classList.toggle("active",repeatMode!=="off");
   r.classList.toggle("repeat-one",repeatMode==="one");
   r.title=repeatMode==="one"?"Repeat satu":"Repeat semua";
 }
}

function toggleShuffle(){
 shuffleEnabled=!shuffleEnabled;
 updateShuffleRepeatUI();
 showToast(shuffleEnabled?"Shuffle aktif":"Shuffle mati");
}

function toggleRepeat(){
 repeatMode=repeatMode==="off"?"all":repeatMode==="all"?"one":"off";
 updateShuffleRepeatUI();
 showToast(repeatMode==="off"?"Repeat mati":repeatMode==="all"?"Repeat semua aktif":"Repeat satu aktif");
}

function getNextIndex(){
 const list=getPlaybackList();
 if(!list.length)return -1;
 const currentIndex=list.findIndex(x=>x.id===currentVideoId);
 if(repeatMode==="one")return currentIndex>=0?currentIndex:0;
 if(shuffleEnabled&&list.length>1){
   let n=currentIndex;
   for(let guard=0;guard<12&&n===currentIndex;guard++)n=Math.floor(Math.random()*list.length);
   return n;
 }
 if(currentIndex>=0){
   if(currentIndex+1<list.length)return currentIndex+1;
   if(repeatMode==="all")return 0;
   return -1;
 }
 return 0;
}

function prevTrack(){
 const list=getPlaybackList();
 if(!list.length){showToast("Antrean kosong");return}
 const currentIndex=list.findIndex(x=>x.id===currentVideoId);
 if(repeatMode==="one"&&currentVideoId){loadYouTubeVideo(currentVideoId,true);return}
 let n;
 if(shuffleEnabled&&list.length>1){
   n=currentIndex;
   for(let guard=0;guard<12&&n===currentIndex;guard++)n=Math.floor(Math.random()*list.length);
 }else{
   n=currentIndex>0?currentIndex:list.length-1;
 }
 playQueueOrTrack(list[n]);
}
function openPage(name){
 if(name==="vip"){renderVipPage();return;}
 document.getElementById("main")?.classList.remove("hidden");
 document.getElementById("page")?.classList.add("hidden");
 const main=document.getElementById("main"),page=document.getElementById("page");if(!main||!page)return;
 document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.page===name));
 if(name==="home"){main.classList.remove("hidden");page.classList.add("hidden");return}
 main.classList.add("hidden");page.classList.remove("hidden");
 const pages={
  explore:`<button class="back" onclick="openPage('home')">‹</button><h1>Eksplor</h1><p class="hero-sub">Cari musik dan video favoritmu.</p>${tracks.map((t,i)=>`<div class="collection-item"><span>${escapeHtml(t.title)}<br><small>${escapeHtml(t.artist)}</small></span><button class="play-small" onclick="playTrack(${i})">▶</button></div>`).join("")}`,
  vip:`<button class="back" onclick="openPage('home')">‹</button><div class="vip-card"><h2>♛ VibeTube VIP</h2><p>Nikmati fitur premium tanpa batas.</p><div class="vip-list">✓ Bebas iklan<br>✓ Putar di latar belakang*<br>✓ Kualitas video tinggi<br>✓ Akses fitur premium</div></div><div class="plan"><b>1 Bulan</b><br>Rp 19.900</div><div class="plan"><b>3 Bulan</b><br>Rp 49.900</div><div class="plan"><b>1 Tahun</b><br>Rp 149.900</div><button class="subscribe" onclick="showToast('Pembayaran VIP akan disambungkan nanti')">Langganan Sekarang</button>`,
  collection:`<button class="back" onclick="openPage('home')">‹</button><h1>Koleksi</h1><div class="collection-item"><span>＋ &nbsp; Buat Playlist Baru</span></div><div class="collection-item"><span>♫ &nbsp; Musik Favorit<br><small>35 video</small></span>⋮</div><div class="collection-item"><span>♫ &nbsp; Lagu Santai<br><small>18 video</small></span>⋮</div>`,
  account:getAccountSummaryHtml()
 };
 page.innerHTML=pages[name]||pages.explore;
 applyVibeLanguage(page);
}



/* ===== VibeTube Google Login (Firebase Authentication) =====
   Firebase config tetap terpisah dari YouTube API Key.
   Jangan ubah YOUTUBE_API_KEY di bawah ini.
*/
const VIBETUBE_FIREBASE_CONFIG={
  apiKey:"AIzaSyC7X_6LK7nQ8EUsjITIhTUHnlLWsvMyr6U",
  authDomain:"vibetube-b1422.firebaseapp.com",
  projectId:"vibetube-b1422",
  storageBucket:"vibetube-b1422.firebasestorage.app",
  messagingSenderId:"149413114315",
  appId:"1:149413114315:web:e429e00ba3f77109e5064e",
  measurementId:"G-07ENQXP63G"
};

let vibetubeAuth=null;
let vibetubeGoogleProvider=null;
let vibetubeUser=null;
let vibetubeGoogleReady=false;
let vibetubeGoogleInitError="";

function escapeAttr(value){ return escapeHtml(String(value||"")).replace(/`/g,"&#096;"); }

function getVibeTubeUser(){
  return vibetubeUser || null;
}

function getAccountSummaryHtml(){
  const u=getVibeTubeUser();
  const name=escapeHtml(u?.displayName||"Vibe User");
  const email=escapeHtml(u?.email||"Belum login");
  return `<button class="back" onclick="openPage('home')">‹</button>
  <h1>Akun</h1>
  <button type="button" class="account-item account-btn" onclick="openAccountSection('profile')">♙ <span>${name}<br><small>${email}</small></span><b>›</b></button>
  <button type="button" class="account-item account-btn" onclick="openAccountSection('google')">G &nbsp; Akun Google <small style="margin-left:auto;color:${u?'#9dff32':'#777'}">${u?'Terhubung':'Belum terhubung'}</small><b>›</b></button>
  <button type="button" class="account-item account-btn" onclick="openPage('vip')">♛ &nbsp; Langganan VIP <b>›</b></button>
  <button type="button" class="account-item account-btn" onclick="openAccountSection('playback')">⚙ &nbsp; Pengaturan Playback <b>›</b></button>
  <button type="button" class="account-item account-btn" onclick="openAccountSection('download')">⇩ &nbsp; Download <b>›</b></button>
  <button type="button" class="account-item account-btn" onclick="openAccountSection('language')">◎ &nbsp; Bahasa　${getVibeLanguage()} <b>›</b></button>`;
}

function isFileOrigin(){
  return window.location.protocol==="file:" || window.location.origin==="null";
}

function initGoogleLogin(){
  if(vibetubeGoogleReady || vibetubeGoogleInitError) return vibetubeGoogleReady;
  if(!window.firebase){
    vibetubeGoogleInitError="Firebase SDK belum dimuat.";
    return false;
  }
  try{
    if(!firebase.apps.length) firebase.initializeApp(VIBETUBE_FIREBASE_CONFIG);
    vibetubeAuth=firebase.auth();
    vibetubeGoogleProvider=new firebase.auth.GoogleAuthProvider();
    vibetubeGoogleProvider.setCustomParameters({prompt:"select_account"});
    vibetubeAuth.setPersistence(firebase.auth.Auth.Persistence.LOCAL).catch(()=>{});

    vibetubeAuth.onAuthStateChanged(user=>{
      vibetubeUser=user||null;
      if(user){
        localStorage.setItem("vibetubeGoogleConnected","true");
      }else{
        localStorage.removeItem("vibetubeGoogleConnected");
      }
      refreshVisibleAccountPage();
    });

    vibetubeAuth.getRedirectResult().catch(err=>{
      if(err && err.code!=="auth/no-auth-event") console.warn("Google redirect result:",err);
    });

    vibetubeGoogleReady=true;
    return true;
  }catch(err){
    console.error("Firebase init:",err);
    vibetubeGoogleInitError=err?.message||"Firebase tidak dapat diinisialisasi.";
    return false;
  }
}

function refreshVisibleAccountPage(){
  const page=document.getElementById("page");
  if(!page || page.classList.contains("hidden")) return;
  if(page.dataset.vibetubeAccountView==="summary") openPage("account");
}

function googleLoginErrorMessage(err){
  const code=err?.code||"";
  if(code==="auth/popup-blocked") return "Popup Google diblokir. VibeTube akan memakai halaman login redirect.";
  if(code==="auth/popup-closed-by-user") return "Login Google dibatalkan.";
  if(code==="auth/cancelled-popup-request") return "Permintaan login sebelumnya dibatalkan.";
  if(code==="auth/unauthorized-domain") return "Domain ini belum diizinkan di Firebase Authentication.";
  if(code==="auth/operation-not-allowed") return "Provider Google belum diaktifkan di Firebase Authentication.";
  if(code==="auth/network-request-failed") return "Koneksi internet bermasalah.";
  return err?.message||"Login Google gagal.";
}

async function connectGoogleAccount(){
  if(!initGoogleLogin()){
    showToast(vibetubeGoogleInitError||"Firebase belum siap");
    return;
  }

  if(isFileOrigin()){
    showToast("Google Login membutuhkan origin HTTPS atau localhost. Jalankan VibeTube dari domain yang terdaftar di Firebase.");
    return;
  }

  try{
    const ua=navigator.userAgent||"";
    const webView=/; wv\)|Version\/\d+\.\d+.*Chrome\/.*Mobile|FB_IAB|Instagram|Line\//i.test(ua);
    if(webView){
      await vibetubeAuth.signInWithRedirect(vibetubeGoogleProvider);
      return;
    }
    await vibetubeAuth.signInWithPopup(vibetubeGoogleProvider);
    showToast("Akun Google berhasil terhubung");
    if(typeof openAccountSection==="function") openAccountSection("google");
  }catch(err){
    if(err?.code==="auth/popup-blocked"){
      try{
        await vibetubeAuth.signInWithRedirect(vibetubeGoogleProvider);
        return;
      }catch(redirectErr){
        showToast(googleLoginErrorMessage(redirectErr));
        return;
      }
    }
    showToast(googleLoginErrorMessage(err));
  }
}

async function disconnectGoogleAccount(){
  if(!vibetubeAuth) return;
  try{
    await vibetubeAuth.signOut();
    showToast("Akun Google dilepas");
    openAccountSection("google");
  }catch(err){
    showToast("Gagal logout akun Google");
  }
}

function getGoogleAccountSectionHtml(){
  const u=getVibeTubeUser();
  if(!u){
    return `<button class="back" onclick="openPage('account')">‹</button><h1>Akun Google</h1>
    <div class="account-sub-card"><div style="font-size:40px;text-align:center;margin:10px">G</div>
    <h2 style="text-align:center">Google belum terhubung</h2>
    <p class="hero-sub" style="text-align:center">Hubungkan akun Google untuk sinkronisasi akun VibeTube.</p></div>
    <button class="account-action gold" onclick="connectGoogleAccount()">Hubungkan Google</button>
    <p class="hero-sub" style="margin-top:12px">Pastikan provider Google sudah diaktifkan di Firebase Authentication dan domain aplikasi sudah terdaftar.</p>`;
  }
  const photo=u.photoURL?`<img src="${escapeAttr(u.photoURL)}" alt="" referrerpolicy="no-referrer" style="width:52px;height:52px;border-radius:50%;object-fit:cover;border:1px solid #6d5a25">`:`<div style="font-size:30px">♙</div>`;
  return `<button class="back" onclick="openPage('account')">‹</button><h1>Akun Google</h1>
  <div class="account-sub-card">
    <div style="display:flex;align-items:center;gap:12px">${photo}<div style="min-width:0"><b>${escapeHtml(u.displayName||"Google User")}</b><br><small>${escapeHtml(u.email||"")}</small></div></div>
    <div class="account-sub-row"><span>Status</span><b style="color:#9dff32">TERHUBUNG</b></div>
  </div>
  <button class="account-action gold" onclick="disconnectGoogleAccount()">Keluar dari Google</button>`;
}

function getProfileSectionHtml(){
  const u=getVibeTubeUser();
  const name=escapeHtml(u?.displayName||"Vibe User");
  const email=escapeHtml(u?.email||"Belum terhubung");
  const action=u?`<button class="account-action gold" onclick="disconnectGoogleAccount()">Keluar</button>`:`<button class="account-action gold" onclick="connectGoogleAccount()">Masuk / Daftar</button>`;
  return `<button class="back" onclick="openPage('account')">‹</button><h1>${name}</h1>
  <div class="account-sub-card"><div style="font-size:22px">♙　<b>${name}</b></div>
  <p class="hero-sub">Profil dan status akun</p>
  <div class="account-sub-row"><span>Nama</span><b>${name}</b></div>
  <div class="account-sub-row"><span>Email</span><b>${email}</b></div>
  <div class="account-sub-row"><span>Status</span><b style="color:#9dff32">${vipStatus==="vip"?"VIP":"FREE"}</b></div></div>${action}`;
}

document.addEventListener("DOMContentLoaded",()=>{ initGoogleLogin(); });

function openAccountSection(section){
 const main=document.getElementById("main"),page=document.getElementById("page");
 if(!main||!page)return;
 main.classList.add("hidden");page.classList.remove("hidden");
 document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.page==="account"));
 const back=`<button class="back" onclick="openPage('account')">‹</button>`;
 const sections={
  profile:getProfileSectionHtml(),
  google:getGoogleAccountSectionHtml(),
  playback:`${back}<h1>Pengaturan Playback</h1><div class="account-sub-card"><div class="account-sub-row"><span>Kualitas Default</span><select id="accQuality" onchange="savePlaybackSetting('quality',this.value)" style="background:#111611;color:#ddd;border:1px solid #303830;border-radius:9px;padding:8px"><option>Audio</option><option>Video</option><option>Auto</option></select></div><div class="account-sub-row"><span>Mode Default</span><select id="accMode" onchange="savePlaybackSetting('mode',this.value)" style="background:#111611;color:#ddd;border:1px solid #303830;border-radius:9px;padding:8px"><option value="audio">Audio</option><option value="video">Video</option></select></div><div class="account-sub-row"><span>Auto Play</span><button id="accAutoSwitch" class="account-switch" onclick="accountToggleAuto()"><i></i></button></div><div class="account-sub-row"><span>Ingat Posisi Terakhir</span><button id="accRememberSwitch" class="account-switch" onclick="accountToggle('remember')"><i></i></button></div></div>`,
  download:`${back}<h1>Download</h1><div class="account-sub-card"><p class="hero-sub">Kelola daftar download VibeTube.</p><div class="account-sub-row"><span>Tersedia</span><b id="downloadCount">0 item</b></div><div class="account-sub-row"><span>Lokasi</span><b>Perangkat</b></div><div class="account-sub-row"><span>Kualitas</span><b>High</b></div></div><button class="account-action" onclick="showToast('Belum ada file download')">Lihat Download</button><p class="hero-sub" style="margin-top:12px">Catatan: pengunduhan video YouTube memerlukan mekanisme sumber yang sesuai; halaman ini baru menyediakan pengelolaannya.</p>`,
  language:`${back}<h1>Bahasa</h1><p class="hero-sub">Pilih bahasa aplikasi.</p><div class="account-sub-card"><button class="account-choice active" onclick="setAppLanguage('Indonesia')">◉　Indonesia</button><button class="account-choice" onclick="setAppLanguage('English')">○　English</button></div>`
 };
 page.innerHTML=sections[section]||sections.profile;
 applyVibeLanguage(page);
 if(section==="playback")initPlaybackSettings();
}
function savePlaybackSetting(key,value){
 localStorage.setItem("vibetubePlayback_"+key,value);
 showToast("Pengaturan disimpan");
}
function accountToggleAuto(){
 toggleAutoPlay();
 initPlaybackSettings();
}
function accountToggle(key){
 const v=localStorage.getItem("vibetubeAccount_"+key)==="true";
 localStorage.setItem("vibetubeAccount_"+key,String(!v));
 initPlaybackSettings();
 showToast((!v)?"Aktif":"Nonaktif");
}
function setSwitch(id,on){
 const b=document.getElementById(id);
 if(b)b.classList.toggle("on",!!on);
}
function initPlaybackSettings(){
 const q=localStorage.getItem("vibetubePlayback_quality")||"Audio";
 const m=localStorage.getItem("vibetubePlayback_mode")||"audio";
 const qel=document.getElementById("accQuality"),mel=document.getElementById("accMode");
 if(qel)qel.value=q;if(mel)mel.value=m;
 setSwitch("accAutoSwitch",autoPlay);
 setSwitch("accRememberSwitch",localStorage.getItem("vibetubeAccount_remember")==="true");
}
function setAppLanguage(lang){
 lang=lang==="English"?"English":"Indonesia";
 localStorage.setItem("vibetubeLanguage",lang);
 document.querySelectorAll(".account-choice").forEach(b=>b.classList.remove("active"));
 event?.currentTarget?.classList.add("active");
 applyVibeLanguage(document.body);
 showToast(tr("Bahasa dipilih: ")+ (lang==="English"?"English":lang));
 // Re-render the current page so every dynamic label follows the selected language.
 const page=document.getElementById("page");
 if(page && !page.classList.contains("hidden")){
   if(typeof openAccountSection==="function") openAccountSection("language");
 }
}

function openSettings(){
 const main=document.getElementById("main"),page=document.getElementById("page");
 if(!main||!page)return;
 main.classList.add("hidden");page.classList.remove("hidden");
 document.querySelectorAll(".nav-item").forEach(x=>x.classList.remove("active"));
 page.innerHTML=`<div class="settings-page">
  <button class="settings-back" onclick="openPage('home')">‹</button>
  <h1>Pengaturan</h1>
  <p class="hero-sub">Atur pengalaman VibeTube sesuai kebutuhanmu.</p>
  <div class="settings-section">Playback</div>
  <div class="settings-card">
   <div class="settings-row"><span><b>Auto Play</b><small>Putar video berikutnya otomatis</small></span><button id="setAuto" class="settings-toggle" type="button" onclick="settingsToggleAuto()"><i></i></button></div>
   <div class="settings-row"><span><b>Mode Pemutaran</b><small>Mode default saat membuka player</small></span><select id="setMode" class="settings-select" onchange="saveSettingsValue('mode',this.value)"><option value="audio">Audio</option><option value="video">Video</option></select></div>
   <div class="settings-row"><span><b>Ingat Posisi</b><small>Simpan posisi terakhir pemutaran</small></span><button id="setRemember" class="settings-toggle" type="button" onclick="settingsToggle('remember')"><i></i></button></div>
  </div>
  <div class="settings-section">Tampilan</div>
  <div class="settings-card">
   <div class="settings-row"><span><b>Tema</b><small>Tampilan VibeTube saat ini</small></span><b>Hitam • Premium</b></div>
   <div class="settings-row"><span><b>Bahasa</b><small>Bahasa antarmuka</small></span><select id="setLang" class="settings-select" onchange="saveSettingsValue('language',this.value)"><option>Indonesia</option><option>English</option></select></div>
  </div>
  <div class="settings-section">Data</div>
  <div class="settings-card">
   <div class="settings-row"><span><b>Reset Pengaturan</b><small>Kembalikan pengaturan VibeTube ke default</small></span><button type="button" class="settings-danger" onclick="resetVibeSettings()">Reset</button></div>
  </div>
 </div>`;
 initSettingsPage();
 applyVibeLanguage(page);
}
function saveSettingsValue(key,value){
 if(key==='mode')localStorage.setItem('vibetubePlayback_mode',value);
 if(key==='language')localStorage.setItem('vibetubeLanguage',value);
 showToast('Pengaturan disimpan');
}
function settingsToggleAuto(){toggleAutoPlay();initSettingsPage();}
function settingsToggle(key){
 const v=localStorage.getItem('vibetubeAccount_'+key)==='true';
 localStorage.setItem('vibetubeAccount_'+key,String(!v));
 initSettingsPage();showToast((!v)?'Aktif':'Nonaktif');
}
function initSettingsPage(){
 setSwitch('setAuto',typeof autoPlay!=='undefined' ? autoPlay : true);
 setSwitch('setRemember',localStorage.getItem('vibetubeAccount_remember')==='true');
 const m=document.getElementById('setMode'),l=document.getElementById('setLang');
 if(m)m.value=localStorage.getItem('vibetubePlayback_mode')||'audio';
 if(l)l.value=localStorage.getItem('vibetubeLanguage')||'Indonesia';
}
function resetVibeSettings(){
 ['vibetubePlayback_mode','vibetubePlayback_quality','vibetubeAccount_remember','vibetubeLanguage'].forEach(k=>localStorage.removeItem(k));
 if(typeof autoPlay!=='undefined')autoPlay=isVipUser();
 try{localStorage.setItem('vibetubeAutoPlay',String(isVipUser()))}catch(e){}
 initSettingsPage();showToast('Pengaturan direset');
}

function showToast(msg){
 const el=document.getElementById("toast");if(!el)return;
 el.textContent=tr(msg);el.classList.add("show");clearTimeout(window.toastTimer);
 window.toastTimer=setTimeout(()=>el.classList.remove("show"),2200);
}

const YOUTUBE_API_KEY="AIzaSyAlelRvc5yWxOW_8HxCVDjawwZKh6XeIo8";

function openSearch(){
 const main=document.getElementById("main"),page=document.getElementById("page");if(!main||!page)return;
 document.querySelectorAll(".nav-item").forEach(x=>x.classList.remove("active"));main.classList.add("hidden");page.classList.remove("hidden");
 page.innerHTML=`<button class="back" onclick="openPage('home')">‹</button><h1>Cari YouTube</h1><p class="hero-sub">Cari musik dan video favoritmu.</p><div style="display:flex;gap:8px;margin:16px 0"><input id="youtubeSearchInput" type="search" placeholder="Cari lagu atau video..." autocomplete="off" style="flex:1;padding:14px;border-radius:12px;border:1px solid #263326;background:#101410;color:#fff;outline:none;font-size:15px"><button onclick="searchYouTube()" style="padding:0 16px;border:0;border-radius:12px;background:#7cff00;color:#050805;font-weight:700;font-size:18px">⌕</button></div><div id="searchStatus" class="hero-sub"></div><div id="youtubeResults" class="track-list"></div>`;
 const input=document.getElementById("youtubeSearchInput");if(input){input.focus();input.addEventListener("keydown",e=>{if(e.key==="Enter")searchYouTube()})}
}

async function searchYouTube(){
 const input=document.getElementById("youtubeSearchInput"),results=document.getElementById("youtubeResults"),status=document.getElementById("searchStatus");if(!input)return;
 const q=input.value.trim();if(!q){status.textContent="Masukkan kata pencarian terlebih dahulu.";return}
 if(!YOUTUBE_API_KEY.trim()){status.textContent="API Key belum dimasukkan ke script.js";return}
 status.textContent="Mencari...";results.innerHTML="";
 try{
  const res=await fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=20&q=${encodeURIComponent(q)}&key=${encodeURIComponent(YOUTUBE_API_KEY)}`);
  const data=await res.json();
  if(!res.ok)throw new Error(data?.error?.message||"Pencarian gagal");
  const items=(data.items||[]).filter(x=>x.id?.videoId);
  if(!items.length){status.textContent="Video tidak ditemukan.";return}
  window.youtubeSearchItems=items;status.textContent=`Ditemukan ${items.length} video`;
  results.innerHTML=items.map((v,i)=>{const sn=v.snippet,thumb=sn.thumbnails?.medium?.url||sn.thumbnails?.default?.url||"";return `<article class="track" onclick="playSearchResult(${i})" style="cursor:pointer"><img src="${thumb}" style="width:110px;height:62px;object-fit:cover;border-radius:8px;background:#111" loading="lazy"><div class="track-info"><b>${escapeHtml(sn.title)}</b><small>${escapeHtml(sn.channelTitle)}</small></div><button class="play-small" onclick="event.stopPropagation();playSearchResult(${i})">▶</button></article>`}).join("");
 }catch(err){status.textContent="Gagal mencari: "+err.message}
}

function playSearchResult(i){
 const v=window.youtubeSearchItems?.[i];if(!v)return;
 const selectedSearchItem={id:v.id.videoId,title:v.snippet.title,artist:v.snippet.channelTitle,duration:"YouTube"};
 if(!queueItems.some(x=>queueKey(x)===queueKey(selectedSearchItem)))queueItems.push(selectedSearchItem);
 renderQueue();
 const sn=v.snippet;
 current=-1;

 setNowPlaying(sn.title,sn.channelTitle,"YouTube",v.id.videoId);
 document.getElementById("playerBar")?.classList.remove("hidden");
 preparePlayerArea();

 currentVideoId=v.id.videoId;
 pendingVideoId=v.id.videoId;
 pendingPlay=false;

 if(ready&&player){
   try{
     player.cueVideoById(v.id.videoId);
     hidePlayerPoster();
   }catch(e){
     console.error(e);
     showToast("Gagal menyiapkan video");
   }
 }else{
   createYouTubePlayer();
   showToast("Menyiapkan pemutar...");
 }
}

function escapeHtml(str){return String(str).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}

document.addEventListener("DOMContentLoaded",()=>{
 updateAutoPlaySwitch();
 renderQueue();
 createYouTubePlayer();
});

updateShuffleRepeatUI();

updateEqUI();

setTimeout(()=>{const b=document.querySelector('.viz-presets button[data-viz="'+vizMode+'"]');if(b)b.classList.add('active')},0);




/* ===== VibeTube multilingual UI FINAL ===== */
const VT_LANG_KEY="vibetubeLanguage";
// Migrasi bahasa lama: Japanese/Korean sudah tidak didukung.
if(["Japanese","Korean","ja","ko"].includes(localStorage.getItem(VT_LANG_KEY))){localStorage.setItem(VT_LANG_KEY,"id");localStorage.setItem("language","id");}
const VT_TRANSLATIONS={
id:{
"Beranda":"Beranda","Eksplor":"Eksplor","Subscription":"Subscription","Koleksi":"Koleksi","Akun":"Akun",
"Rekomendasi":"Rekomendasi","Lihat semua ›":"Lihat semua ›","Musik":"Musik","Video":"Video","Playlist":"Playlist","Favorit":"Favorit","Trending":"Trending",
"Dengarkan & Tonton":"Dengarkan & Tonton","Tanpa Batas":"Tanpa Batas","Musik dan video favorit dalam satu pemutar.":"Musik dan video favorit dalam satu pemutar.",
"Cari":"Cari","Pengaturan":"Pengaturan","Sekarang Diputar":"Sekarang Diputar","Pilih video":"Pilih video","Berikutnya":"Berikutnya","Auto play":"Auto play",
"Audio":"Audio","Video":"Video","Audio Mode":"Audio Mode","Queue":"Queue","Sleep Timer":"Sleep Timer","Equalizer":"Equalizer","Visualizer":"Visualizer",
"Download":"Download","Bahasa":"Bahasa","Playback":"Playback","Pengaturan Playback":"Pengaturan Playback","Ingat Posisi":"Ingat Posisi",
"English":"English","Indonesia":"Indonesia","Reset Pengaturan":"Reset Pengaturan",
"VIP":"VIP","VibeTube Premium":"VibeTube Premium","Upgrade ke VibeTube VIP":"Upgrade ke VibeTube VIP"
},
en:{
"Beranda":"Home","Eksplor":"Explore","Subscription":"Subscription","Koleksi":"Library","Akun":"Account",
"Rekomendasi":"Recommendations","Lihat semua ›":"See all ›","Musik":"Music","Video":"Video","Playlist":"Playlists","Favorit":"Favorites","Trending":"Trending",
"Dengarkan & Tonton":"Listen & Watch","Tanpa Batas":"Without Limits","Musik dan video favorit dalam satu pemutar.":"Music and favorite videos in one player.",
"Cari":"Search","Pengaturan":"Settings","Sekarang Diputar":"Now Playing","Pilih video":"Select a video","Berikutnya":"Up Next","Auto play":"Auto Play",
"Audio":"Audio","Video":"Video","Audio Mode":"Audio Mode","Queue":"Queue","Sleep Timer":"Sleep Timer","Equalizer":"Equalizer","Visualizer":"Visualizer",
"Download":"Downloads","Bahasa":"Language","Playback":"Playback","Pengaturan Playback":"Playback Settings","Ingat Posisi":"Remember Position",
"English":"English","Indonesia":"Indonesian","Reset Pengaturan":"Reset Settings",
"VIP":"VIP","VibeTube Premium":"VibeTube Premium","Upgrade ke VibeTube VIP":"Upgrade to VibeTube VIP"
},
};

function getVibeTubeLanguage(){
  const v=localStorage.getItem(VT_LANG_KEY)||localStorage.getItem("language")||"id";
  if(v==="ja"||v==="ko") { localStorage.setItem(VT_LANG_KEY,"id"); localStorage.setItem("language","id"); return "id"; }
  return ["id","en"].includes(v)?v:"id";
}
function vtT(text){
  const lang=getVibeTubeLanguage();
  return (VT_TRANSLATIONS[lang]&&VT_TRANSLATIONS[lang][text])||text;
}
function vtTranslate(root=document.body){
  if(!root)return;
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
  const list=[];
  while(walker.nextNode())list.push(walker.currentNode);
  list.forEach(node=>{
    const raw=node.nodeValue;
    const trimmed=raw.trim();
    if(!trimmed)return;
    const translated=vtT(trimmed);
    if(translated!==trimmed){
      node.nodeValue=raw.replace(trimmed,translated);
    }
  });
  root.querySelectorAll("[placeholder]").forEach(el=>{
    const p=el.getAttribute("placeholder");
    const t=vtT(p);
    if(t!==p)el.setAttribute("placeholder",t);
  });
}
function refreshVibeTubeLanguage(){
  vtTranslate(document.body);
  setTimeout(()=>vtTranslate(document.body),30);
  setTimeout(()=>vtTranslate(document.body),250);
}
function setVibeTubeLanguage(lang){
  lang=lang==="en"?"en":"id";
  localStorage.setItem(VT_LANG_KEY,lang);
  localStorage.setItem("language",lang);
  refreshVibeTubeLanguage();
  const msg={id:"Bahasa diubah ke Indonesia",en:"Language changed to English"}[lang];
  if(typeof showToast==="function")setTimeout(()=>showToast(msg),80);
}
window.setVibeTubeLanguage=setVibeTubeLanguage;
window.vtTranslate=vtTranslate;

document.addEventListener("DOMContentLoaded",()=>{
  refreshVibeTubeLanguage();
  const observer=new MutationObserver(mutations=>{
    for(const m of mutations){
      if(m.addedNodes&&m.addedNodes.length){refreshVibeTubeLanguage();break;}
    }
  });
  observer.observe(document.body,{childList:true,subtree:true});
});


window.VIBETUBE_BUILD="2026-09-01-google-firebase-final";

window.VIBETUBE_BUILD="2026-09-01-autoplay-vip";


/* ===== VibeTube VIP - ShopeePay Manual Payment =====
   Isi nomor penerima Anda di bawah. Gunakan nomor HP ShopeePay tanpa spasi.
   Contoh: "081234567890"
*/
const VIBETUBE_SHOPEEPAY_NUMBER = "081386223924";
const VIBETUBE_VIP_MONTHLY_PRICE = 19000;
const VIBETUBE_VIP_YEARLY_PRICE = 149900;

function isShopeePayNumberConfigured(){
  return /^(\+62|62|0)8\d{8,12}$/.test(VIBETUBE_SHOPEEPAY_NUMBER.replace(/\s+/g,""));
}
function formatRupiah(n){
  return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);
}
function openVipPayment(){
  const main=document.getElementById("main"),page=document.getElementById("page");
  if(!main||!page)return;
  main.classList.add("hidden"); page.classList.remove("hidden");
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.remove("active"));
  const numberText=isShopeePayNumberConfigured()?VIBETUBE_SHOPEEPAY_NUMBER:"Belum dikonfigurasi";
  page.innerHTML=`
    <button class="back" onclick="openPage('vip')">‹</button>
    <h1>Bayar VibeTube VIP</h1>
    <p class="hero-sub">Pilih paket, lalu lakukan pembayaran ke ShopeePay.</p>
    <div class="account-sub-card">
      <div class="account-sub-row"><span>VIP Bulanan</span><b>${formatRupiah(VIBETUBE_VIP_MONTHLY_PRICE)}</b></div>
      <button class="account-action gold" onclick="selectVipPayment('monthly')">Pilih VIP Bulanan</button>
      <div style="height:12px"></div>
      <div class="account-sub-row"><span>VIP Tahunan</span><b>${formatRupiah(VIBETUBE_VIP_YEARLY_PRICE)}</b></div>
      <button class="account-action gold" onclick="selectVipPayment('yearly')">Pilih VIP Tahunan</button>
    </div>
    <div id="vipPaymentDetail"></div>
  `;
}
function selectVipPayment(plan){
  const detail=document.getElementById("vipPaymentDetail");
  if(!detail)return;
  const amount=plan==="yearly"?VIBETUBE_VIP_YEARLY_PRICE:VIBETUBE_VIP_MONTHLY_PRICE;
  const label=plan==="yearly"?"VIP Tahunan":"VIP Bulanan";
  if(!isShopeePayNumberConfigured()){
    detail.innerHTML=`<div class="account-sub-card"><h2>Nomor ShopeePay belum diisi</h2><p class="hero-sub">Pemilik aplikasi harus mengisi VIBETUBE_SHOPEEPAY_NUMBER di script.js.</p></div>`;
    return;
  }
  localStorage.setItem("vibetubePendingVipPlan",plan);
  localStorage.setItem("vibetubePendingVipAmount",String(amount));
  detail.innerHTML=`
    <div class="account-sub-card">
      <h2>${label}</h2>
      <p class="hero-sub">Total pembayaran</p>
      <div style="font-size:26px;font-weight:800;margin:8px 0 16px">${formatRupiah(amount)}</div>
      <div class="account-sub-row"><span>Penerima ShopeePay</span><b id="shopeeNumber">${VIBETUBE_SHOPEEPAY_NUMBER}</b></div>
      <button class="account-action" onclick="copyShopeePayNumber()">Salin Nomor ShopeePay</button>
      <p class="hero-sub" style="margin-top:14px">Setelah transfer, tekan tombol di bawah. Status VIP tidak aktif otomatis hanya dengan tombol ini; pembayaran harus diverifikasi terlebih dahulu.</p>
      <button class="account-action gold" onclick="submitPaymentConfirmation()">Saya Sudah Bayar</button>
    </div>
  `;
}
async function copyShopeePayNumber(){
  try{
    await navigator.clipboard.writeText(VIBETUBE_SHOPEEPAY_NUMBER);
    showToast("Nomor ShopeePay disalin");
  }catch(e){
    showToast("Salin nomor: "+VIBETUBE_SHOPEEPAY_NUMBER);
  }
}
function submitPaymentConfirmation(){
  const plan=localStorage.getItem("vibetubePendingVipPlan");
  if(!plan){ showToast("Pilih paket terlebih dahulu"); return; }
  localStorage.setItem("vibetubePaymentConfirmation","pending");
  localStorage.setItem("vibetubePaymentConfirmationTime",new Date().toISOString());
  showToast("Konfirmasi pembayaran dikirim. Menunggu verifikasi.");
  setTimeout(()=>openPage("vip"),300);
}
window.openVipPayment=openVipPayment;
window.selectVipPayment=selectVipPayment;
window.copyShopeePayNumber=copyShopeePayNumber;
window.submitPaymentConfirmation=submitPaymentConfirmation;

window.openVipPayment=openVipPayment;
window.VIBETUBE_BUILD="2026-09-01-shopeepay-manual-vip";

window.VIBETUBE_BUILD="2026-09-01-shopeepay-vip-fixed-no-demo";
