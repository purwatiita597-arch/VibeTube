VibeTube Player v2

Pemutar YouTube dengan Play/Pause, Next/Previous, progress, seek, mini-player, dan mode Audio/Video.

Buka index.html di Acode Preview dengan internet aktif.
Login Google dan VIP masih prototype. Gunakan player YouTube resmi.
