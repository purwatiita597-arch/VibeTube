package com.vibetube.player;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
 @SuppressLint("SetJavaScriptEnabled")
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  WebView w=new WebView(this);
  WebSettings s=w.getSettings();
  s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
  w.setWebViewClient(new WebViewClient()); w.setWebChromeClient(new WebChromeClient());
  w.loadUrl("file:///android_asset/index.html"); setContentView(w);
 }
 @Override public void onBackPressed(){ super.onBackPressed(); }
}
